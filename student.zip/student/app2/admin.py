from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(Admindata)
admin.site.register(Accountantdata)
admin.site.register(Studentdata)
admin.site.register(Logindata)
admin.site.register(Coursedata)
admin.site.register(StudentCoursedata)
admin.site.register(Installmentdata)
admin.site.register(Photodata)